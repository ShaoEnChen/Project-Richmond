from django.contrib import admin
from .models import trade

admin.site.register(trade)